<section id="oscars">
    <div>
       <!-- <div class="oscars_div"> -->
        <h3 class="oscars_div_text">Fleurs d’oranger & chats errants est nominé aux Oscars Short Film Animated de 2022 !</h3>
    <!-- </div> -->
       <img src="<?php echo get_stylesheet_directory_uri() . '/assets/images/18-courts-metrages-francais-d-animation-eligibles-aux-oscars-2021 1.png'; ?> " alt="Nomination oscars">
    </div>
</section>
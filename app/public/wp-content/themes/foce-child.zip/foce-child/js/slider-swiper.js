//window.addEventListener('load', (event) => {

  var swiper = new Swiper(".mySwiper", {
    effect: "coverflow",
    autoplay: {
      delay: 3000,
    },
    grabCursor: true,
    centeredSlides: true,
    slidesPerView: 3,
    loop: true,
    loopedSlides: 2,
    coverflowEffect: {
      rotate: 65,
      stretch: 0,
      slideShadows: false,
    },
  });
  
  var appendNumber = 4;
  var prependNumber = 4;

  
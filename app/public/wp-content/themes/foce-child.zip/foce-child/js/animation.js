window.addEventListener("DOMContentLoaded", (event) => {

const storyTitle = document.querySelector('.story__title');
const studioTitle = document.querySelector('.studio__div__title-first');
const koukakiTitle = document.querySelector('.studio__div__title-second');
const littleCloud = document.querySelector('#place h3');

//Renvoie la taille de l' élément et sa position par rapport à la fenêtre
const {scrollTop, clientHeight} = document.documentElement;

  window.addEventListener(
    "scroll",
    () => {
      /**
       * ACTIVATION DES ANIMATIONS AU SCROLL
       */
        // TITRE HISTOIRE
        const topStoryTitleToTopViewport = storyTitle.getBoundingClientRect().top;
        if(scrollTop > (scrollTop + topStoryTitleToTopViewport).toFixed() - clientHeight * 0.80){
          storyTitle.classList.add('active');
        }
        // TITRE STUDIO
        const topStudioTitleToTopViewport = studioTitle.getBoundingClientRect().top;
        if(scrollTop > (scrollTop + topStudioTitleToTopViewport).toFixed() - clientHeight * 0.80){
          studioTitle.classList.add('active');
        }
        // TITRE KOUKAKI
        const topKoukakiTitleToTopViewport = koukakiTitle.getBoundingClientRect().top;
        if(scrollTop > (scrollTop + topKoukakiTitleToTopViewport).toFixed() - clientHeight * 0.80){
          koukakiTitle.classList.add('active');
        }
        //  PETIT NUAGE
        const topLittleCloudToTopViewport = littleCloud.getBoundingClientRect().top;
        if(scrollTop > (scrollTop + topLittleCloudToTopViewport).toFixed() - clientHeight * 0.80){
          littleCloud.classList.add('active');
          document.body.style.setProperty(
            "--scroll",
            window.pageYOffset / window.innerHeight
          );
        }
    },
    false
  );
});
